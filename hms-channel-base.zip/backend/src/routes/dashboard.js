import express from 'express';
import Reservation from '../models/Reservation.js';
import Transaction from '../models/Transaction.js';
import Hotel from '../models/Hotel.js';
import { auth } from '../middleware/auth.js';

const router = express.Router();

router.get('/overview', auth, async (req, res) => {
  let hotelFilter = {};
  if (req.user.role !== 'MASTER_ADMIN') {
    hotelFilter.hotel = req.user.hotel?._id;
  }

  const [hotelsCount, reservations, transactions] = await Promise.all([
    req.user.role === 'MASTER_ADMIN' ? Hotel.countDocuments() : Promise.resolve(null),
    Reservation.find(hotelFilter),
    Transaction.find(hotelFilter),
  ]);

  const today = new Date();
  today.setHours(0,0,0,0);

  const occToday = reservations.filter(r => r.checkIn <= today && r.checkOut > today && r.status === 'confirmed').length;
  const totalRes = reservations.length;
  const income = transactions.filter(t => t.type === 'income').reduce((a,b)=>a+b.amount,0);
  const expense = transactions.filter(t => t.type === 'expense').reduce((a,b)=>a+b.amount,0);

  res.json({
    hotelsCount,
    totalReservations: totalRes,
    occupancyToday: occToday,
    income,
    expense,
    net: income - expense,
  });
});

export default router;