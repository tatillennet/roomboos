import React, { useEffect, useState } from 'react'
import api from '../../api/axios'
import Header from '../../components/Header'

export default function HotelDashboard(){
  const [data, setData] = useState(null)
  useEffect(()=>{
    api.get('/dashboard/overview').then(res => setData(res.data))
  },[])

  return (
    <div>
      <Header title="Otel Dashboard" subtitle="Özet" />
      <div className="kpis">
        <div className="card"><div className="label">Bugün Doluluk</div><div className="value">{data?.occupancyToday ?? '-'}</div></div>
        <div className="card"><div className="label">Toplam Rezervasyon</div><div className="value">{data?.totalReservations ?? '-'}</div></div>
        <div className="card"><div className="label">Gelir</div><div className="value">{(data?.income ?? 0).toLocaleString()} ₺</div></div>
        <div className="card"><div className="label">Gider</div><div className="value">{(data?.expense ?? 0).toLocaleString()} ₺</div></div>
      </div>
    </div>
  )
}