import React, { useEffect, useState } from 'react'
import api from '../../api/axios'
import Header from '../../components/Header'

export default function Hotels(){
  const [hotels, setHotels] = useState([])
  const [form, setForm] = useState({ name:'', code:'', address:'', phone:'' })
  const load = () => api.get('/hotels').then(res => setHotels(res.data))
  useEffect(()=>{ load() },[])
  const create = async (e) => {
    e.preventDefault()
    await api.post('/hotels', form)
    setForm({ name:'', code:'', address:'', phone:'' })
    load()
  }
  return (
    <div>
      <Header title="Oteller" subtitle="Kayıtlı Oteller" />
      <div className="card" style={{marginBottom:16}}>
        <form className="form-grid" onSubmit={create}>
          <input className="input" placeholder="Ad" value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/>
          <input className="input" placeholder="Kod" value={form.code} onChange={e=>setForm({...form,code:e.target.value})}/>
          <input className="input" placeholder="Adres" value={form.address} onChange={e=>setForm({...form,address:e.target.value})}/>
          <input className="input" placeholder="Telefon" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/>
          <button className="btn primary" type="submit">Ekle</button>
        </form>
      </div>
      <div className="card">
        <table className="table">
          <thead><tr><th>Ad</th><th>Kod</th><th>Telefon</th><th>Oluşturma</th></tr></thead>
          <tbody>
            {hotels.map(h => (
              <tr key={h._id}>
                <td>{h.name}</td>
                <td>{h.code}</td>
                <td>{h.phone || '-'}</td>
                <td>{new Date(h.createdAt).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}