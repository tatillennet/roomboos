import React, { useEffect, useState } from 'react'
import api from '../../api/axios'
import Header from '../../components/Header'

export default function Reservations(){
  const [items, setItems] = useState([])
  const [form, setForm] = useState({
    guestName:'', checkIn:'', checkOut:'', adults:2, children:0, totalPrice:'', channel:'direct', status:'confirmed'
  })
  const load = () => api.get('/reservations').then(res => setItems(res.data))
  useEffect(()=>{ load() },[])

  const create = async (e) => {
    e.preventDefault()
    await api.post('/reservations', {...form, totalPrice: Number(form.totalPrice)})
    setForm({ guestName:'', checkIn:'', checkOut:'', adults:2, children:0, totalPrice:'', channel:'direct', status:'confirmed' })
    load()
  }

  return (
    <div>
      <Header title="Rezervasyonlar" subtitle="Liste ve Ekle" />
      <div className="card" style={{marginBottom:16}}>
        <form className="form-grid" onSubmit={create}>
          <input className="input" placeholder="Misafir Adı" value={form.guestName} onChange={e=>setForm({...form,guestName:e.target.value})}/>
          <input className="input" type="date" value={form.checkIn} onChange={e=>setForm({...form,checkIn:e.target.value})}/>
          <input className="input" type="date" value={form.checkOut} onChange={e=>setForm({...form,checkOut:e.target.value})}/>
          <input className="input" type="number" placeholder="Yetişkin" value={form.adults} onChange={e=>setForm({...form,adults:e.target.value})}/>
          <input className="input" type="number" placeholder="Çocuk" value={form.children} onChange={e=>setForm({...form,children:e.target.value})}/>
          <input className="input" type="number" placeholder="Toplam Fiyat" value={form.totalPrice} onChange={e=>setForm({...form,totalPrice:e.target.value})}/>
          <select className="select" value={form.channel} onChange={e=>setForm({...form,channel:e.target.value})}>
            <option value="direct">Doğrudan</option>
            <option value="airbnb">Airbnb</option>
            <option value="booking">Booking</option>
            <option value="etstur">Etstur</option>
          </select>
          <select className="select" value={form.status} onChange={e=>setForm({...form,status:e.target.value})}>
            <option value="confirmed">Onaylı</option>
            <option value="pending">Beklemede</option>
            <option value="cancelled">İptal</option>
          </select>
          <button className="btn primary">Ekle</button>
        </form>
      </div>
      <div className="card">
        <table className="table">
          <thead><tr><th>Misafir</th><th>Giriş</th><th>Çıkış</th><th>Kanal</th><th>Durum</th><th>Fiyat</th></tr></thead>
        <tbody>
        {items.map(r => (
          <tr key={r._id}>
            <td>{r.guestName}</td>
            <td>{new Date(r.checkIn).toLocaleDateString()}</td>
            <td>{new Date(r.checkOut).toLocaleDateString()}</td>
            <td>{r.channel}</td>
            <td>{r.status}</td>
            <td>{r.totalPrice?.toLocaleString()} ₺</td>
          </tr>
        ))}
        </tbody>
        </table>
      </div>
    </div>
  )
}