import React, { useState } from 'react'
import { useNavigate, useLocation } from 'react-router-dom'
import api from '../api/axios'

export default function Login(){
  const [email, setEmail] = useState('master@demo.local')
  const [password, setPassword] = useState('Master123!')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const navigate = useNavigate()
  const location = useLocation()

  const onSubmit = async (e) => {
    e.preventDefault()
    setLoading(true); setError(null)
    try{
      const { data } = await api.post('/auth/login', { email, password })
      localStorage.setItem('token', data.token)
      localStorage.setItem('role', data.user.role)
      localStorage.setItem('email', data.user.email)
      if (data.user.hotelId) localStorage.setItem('hotelId', data.user.hotelId)
      const redirectTo = location.state?.from?.pathname || '/'
      navigate(redirectTo)
    }catch(err){
      setError(err.response?.data?.message || 'Giriş başarısız')
    }finally{
      setLoading(false)
    }
  }

  return (
    <div className="login-wrapper">
      <div className="login-card">
        <h1>Panele Giriş</h1>
        <p className="muted">Master veya Otel kullanıcısı ile giriş yapın</p>
        <form onSubmit={onSubmit} style={{display:'grid', gap:10}}>
          <input className="input" placeholder="Email" value={email} onChange={e=>setEmail(e.target.value)} />
          <input className="input" placeholder="Şifre" type="password" value={password} onChange={e=>setPassword(e.target.value)} />
          {error && <div style={{color:'var(--danger)'}}>{error}</div>}
          <button className="btn primary" disabled={loading}>{loading? 'Giriş yapılıyor...' : 'Giriş yap'}</button>
          <div className="muted" style={{fontSize:12}}>
            Örnekler: master@demo.local / Master123! — hotel1@demo.local / Demo123!
          </div>
        </form>
      </div>
    </div>
  )
}