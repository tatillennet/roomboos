import jwt from 'jsonwebtoken';
import User from '../models/User.js';

export const auth = async (req, res, next) => {
  const header = req.headers.authorization;
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ message: 'Yetkisiz' });
  }
  const token = header.split(' ')[1];
  try {
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(payload.id).populate('hotel');
    if (!user) return res.status(401).json({ message: 'Geçersiz kullanıcı' });
    req.user = user;
    next();
  } catch (e) {
    return res.status(401).json({ message: 'Token hatası' });
  }
};

export const requireRole = (...roles) => (req, res, next) => {
  if (!req.user || !roles.includes(req.user.role)) {
    return res.status(403).json({ message: 'Erişim engellendi' });
  }
  next();
};