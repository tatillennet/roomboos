import mongoose from 'mongoose';

const ReservationSchema = new mongoose.Schema({
  hotel: { type: mongoose.Schema.Types.ObjectId, ref: 'Hotel', required: true },
  channel: { type: String, enum: ['direct', 'airbnb', 'booking', 'etstur'], default: 'direct' },
  guestName: { type: String, required: true },
  checkIn: { type: Date, required: true },
  checkOut: { type: Date, required: true },
  adults: { type: Number, default: 2 },
  children: { type: Number, default: 0 },
  totalPrice: { type: Number, required: true },
  currency: { type: String, default: 'TRY' },
  status: { type: String, enum: ['pending', 'confirmed', 'cancelled'], default: 'confirmed' },
  notes: String,
}, { timestamps: true });

export default mongoose.model('Reservation', ReservationSchema);