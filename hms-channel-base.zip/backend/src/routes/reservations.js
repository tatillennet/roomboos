import express from 'express';
import Reservation from '../models/Reservation.js';
import { auth, requireRole } from '../middleware/auth.js';

const router = express.Router();

// List (scoped by role)
router.get('/', auth, async (req, res) => {
  let filter = {};
  if (req.user.role !== 'MASTER_ADMIN') {
    filter.hotel = req.user.hotel?._id;
  } else if (req.query.hotelId) {
    filter.hotel = req.query.hotelId;
  }
  const items = await Reservation.find(filter).sort({ checkIn: -1 });
  res.json(items);
});

// Create
router.post('/', auth, requireRole('HOTEL_ADMIN', 'HOTEL_STAFF'), async (req, res) => {
  const hotel = req.user.hotel?._id;
  if (!hotel) return res.status(400).json({ message: 'Kullanıcının bağlı olduğu bir otel yok' });
  const created = await Reservation.create({ ...req.body, hotel });
  res.status(201).json(created);
});

// Update
router.put('/:id', auth, requireRole('HOTEL_ADMIN', 'HOTEL_STAFF'), async (req, res) => {
  const hotel = req.user.hotel?._id;
  const updated = await Reservation.findOneAndUpdate({ _id: req.params.id, hotel }, req.body, { new: true });
  if (!updated) return res.status(404).json({ message: 'Bulunamadı' });
  res.json(updated);
});

// Delete
router.delete('/:id', auth, requireRole('HOTEL_ADMIN'), async (req, res) => {
  const hotel = req.user.hotel?._id;
  const deleted = await Reservation.findOneAndDelete({ _id: req.params.id, hotel });
  if (!deleted) return res.status(404).json({ message: 'Bulunamadı' });
  res.json({ ok: true });
});

export default router;