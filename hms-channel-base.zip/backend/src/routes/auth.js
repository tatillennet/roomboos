import express from 'express';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';

const router = express.Router();

router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email }).populate('hotel');
  if (!user) return res.status(400).json({ message: 'Email veya şifre hatalı' });
  const ok = await user.compare(password);
  if (!ok) return res.status(400).json({ message: 'Email veya şifre hatalı' });

  const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '7d' });
  res.json({
    token,
    user: {
      id: user._id,
      name: user.name,
      email: user.email,
      role: user.role,
      hotelId: user.hotel?._id || null,
      hotelName: user.hotel?.name || null,
    },
  });
});

export default router;