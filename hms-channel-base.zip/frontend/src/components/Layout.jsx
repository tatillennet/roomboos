import React from 'react'
import { NavLink, useNavigate } from 'react-router-dom'

export default function Layout({ children, role }) {
  const navigate = useNavigate()
  const logout = () => {
    localStorage.clear()
    navigate('/login')
  }
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand"><span className="dot"></span> HMS & Channels</div>
        <nav className="nav">
          {role === 'MASTER_ADMIN' ? (
            <>
              <NavLink to="/" end>Dashboard</NavLink>
              <NavLink to="/master/hotels">Oteller</NavLink>
            </>
          ) : (
            <>
              <NavLink to="/" end>Dashboard</NavLink>
              <NavLink to="/hotel/reservations">Rezervasyonlar</NavLink>
              <NavLink to="/hotel/finance">Gelir-Gider</NavLink>
              <NavLink to="/hotel/channels">Kanallar</NavLink>
            </>
          )}
          <a onClick={logout} style={{cursor:'pointer'}}>Çıkış</a>
        </nav>
      </aside>
      <div>
        <header className="header">
          <div className="muted">Hoş geldiniz</div>
          <div>{localStorage.getItem('email')}</div>
        </header>
        <main className="content">{children}</main>
      </div>
    </div>
  )
}