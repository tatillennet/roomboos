export async function sync(hotelId) {
  // Placeholder: burada Etstur API çağrıları olacaktır.
  return { channel: 'etstur', hotelId, message: 'Simüle senkronizasyon tamamlandı' };
}