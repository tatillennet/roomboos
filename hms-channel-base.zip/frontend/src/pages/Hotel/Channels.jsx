import React, { useEffect, useState } from 'react'
import api from '../../api/axios'
import Header from '../../components/Header'

export default function Channels(){
  const [items, setItems] = useState([])
  const [form, setForm] = useState({ channel:'airbnb', credentials:'' })
  const load = () => api.get('/channels').then(res => setItems(res.data))
  useEffect(()=>{ load() },[])

  const connect = async (e) => {
    e.preventDefault()
    await api.post('/channels/connect', { channel: form.channel, credentials: { raw: form.credentials } })
    setForm({ channel:'airbnb', credentials:'' })
    load()
  }

  const sync = async (channel) => {
    await api.post(`/channels/${channel}/sync`)
    alert(channel + ' sync tetiklendi (demo)')
  }

  const available = ['airbnb','booking','etstur']

  return (
    <div>
      <Header title="Kanal Yönetimi" subtitle="Bağlantılar" />
      <div className="card" style={{marginBottom:16}}>
        <form className="form-grid" onSubmit={connect}>
          <select className="select" value={form.channel} onChange={e=>setForm({...form, channel:e.target.value})}>
            {available.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
          <input className="input" placeholder="Kimlik/Token (demo)" value={form.credentials} onChange={e=>setForm({...form, credentials:e.target.value})}/>
          <button className="btn primary">Bağla / Güncelle</button>
        </form>
      </div>

      <div className="kpis">
        {available.map(c => {
          const row = items.find(i => i.channel === c)
          const active = row?.active
          return (
            <div className="card" key={c}>
              <div className="label">{c.toUpperCase()}</div>
              <div className="value">{active ? 'Bağlı' : 'Bağlı değil'}</div>
              <div style={{marginTop:10, display:'flex', gap:8}}>
                <button className="btn" onClick={()=>sync(c)}>Sync</button>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}