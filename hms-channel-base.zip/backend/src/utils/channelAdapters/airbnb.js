export async function sync(hotelId) {
  // Placeholder: burada Airbnb API çağrıları olacaktır.
  return { channel: 'airbnb', hotelId, message: 'Simüle senkronizasyon tamamlandı' };
}