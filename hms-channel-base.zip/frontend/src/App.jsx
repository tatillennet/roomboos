import React, { useMemo } from 'react'
import { Routes, Route, Navigate, useLocation } from 'react-router-dom'
import Layout from './components/Layout.jsx'
import Login from './pages/Login.jsx'
import MasterDashboard from './pages/Master/Dashboard.jsx'
import Hotels from './pages/Master/Hotels.jsx'
import HotelDashboard from './pages/Hotel/Dashboard.jsx'
import Reservations from './pages/Hotel/Reservations.jsx'
import Finance from './pages/Hotel/Finance.jsx'
import Channels from './pages/Hotel/Channels.jsx'

function RequireAuth({ children }){
  const token = localStorage.getItem('token')
  const location = useLocation()
  if (!token) return <Navigate to="/login" state={{ from: location }} replace />
  return children
}

export default function App(){
  const role = localStorage.getItem('role') || 'GUEST'
  const layout = (children) => <Layout role={role}>{children}</Layout>

  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/" element={<RequireAuth>{layout(role === 'MASTER_ADMIN' ? <MasterDashboard/> : <HotelDashboard/>)}</RequireAuth>} />
      <Route path="/master/hotels" element={<RequireAuth>{layout(<Hotels />)}</RequireAuth>} />
      <Route path="/hotel/reservations" element={<RequireAuth>{layout(<Reservations />)}</RequireAuth>} />
      <Route path="/hotel/finance" element={<RequireAuth>{layout(<Finance />)}</RequireAuth>} />
      <Route path="/hotel/channels" element={<RequireAuth>{layout(<Channels />)}</RequireAuth>} />
      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  )
}