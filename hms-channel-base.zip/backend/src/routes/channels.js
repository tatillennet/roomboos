import express from 'express';
import ChannelConnection from '../models/ChannelConnection.js';
import { auth, requireRole } from '../middleware/auth.js';
import * as airbnb from '../utils/channelAdapters/airbnb.js';
import * as booking from '../utils/channelAdapters/booking.js';
import * as etstur from '../utils/channelAdapters/etstur.js';

const router = express.Router();

// list connections
router.get('/', auth, requireRole('HOTEL_ADMIN', 'HOTEL_STAFF'), async (req, res) => {
  const hotel = req.user.hotel?._id;
  const items = await ChannelConnection.find({ hotel });
  res.json(items);
});

// connect/update credentials
router.post('/connect', auth, requireRole('HOTEL_ADMIN'), async (req, res) => {
  const hotel = req.user.hotel?._id;
  const { channel, credentials } = req.body;
  const updated = await ChannelConnection.findOneAndUpdate(
    { hotel, channel },
    { hotel, channel, credentials, active: true },
    { upsert: true, new: true }
  );
  res.json(updated);
});

// sync (demo)
router.post('/:channel/sync', auth, requireRole('HOTEL_ADMIN'), async (req, res) => {
  const hotel = req.user.hotel?._id;
  const { channel } = req.params;
  let result;
  if (channel === 'airbnb') result = await airbnb.sync(hotel);
  else if (channel === 'booking') result = await booking.sync(hotel);
  else if (channel === 'etstur') result = await etstur.sync(hotel);
  else return res.status(400).json({ message: 'Bilinmeyen kanal' });
  res.json({ ok: true, result });
});

export default router;