import React, { useEffect, useState } from 'react'
import api from '../../api/axios'
import Header from '../../components/Header'

export default function MasterDashboard(){
  const [data, setData] = useState(null)
  useEffect(()=>{
    api.get('/dashboard/overview').then(res => setData(res.data))
  },[])

  return (
    <div>
      <Header title="Master Dashboard" subtitle="Genel Bakış" />
      <div className="kpis">
        <div className="card"><div className="label">Otel Sayısı</div><div className="value">{data?.hotelsCount ?? '-'}</div></div>
        <div className="card"><div className="label">Toplam Rezervasyon</div><div className="value">{data?.totalReservations ?? '-'}</div></div>
        <div className="card"><div className="label">Toplam Gelir</div><div className="value">{(data?.income ?? 0).toLocaleString()} ₺</div></div>
        <div className="card"><div className="label">Toplam Gider</div><div className="value">{(data?.expense ?? 0).toLocaleString()} ₺</div></div>
      </div>
    </div>
  )
}