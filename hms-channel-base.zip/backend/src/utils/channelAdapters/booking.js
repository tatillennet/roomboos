export async function sync(hotelId) {
  // Placeholder: burada Booking.com API çağrıları olacaktır.
  return { channel: 'booking', hotelId, message: 'Simüle senkronizasyon tamamlandı' };
}