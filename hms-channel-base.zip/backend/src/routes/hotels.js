import express from 'express';
import Hotel from '../models/Hotel.js';
import User from '../models/User.js';
import { auth, requireRole } from '../middleware/auth.js';

const router = express.Router();

// Master: otelleri listele/oluştur
router.get('/', auth, requireRole('MASTER_ADMIN'), async (req, res) => {
  const hotels = await Hotel.find().sort({ createdAt: -1 });
  res.json(hotels);
});

router.post('/', auth, requireRole('MASTER_ADMIN'), async (req, res) => {
  const { name, code, address, phone } = req.body;
  const hotel = await Hotel.create({ name, code, address, phone, createdBy: req.user._id });
  res.status(201).json(hotel);
});

// Hotel admin: kendi otelini getir
router.get('/me', auth, requireRole('HOTEL_ADMIN', 'HOTEL_STAFF'), async (req, res) => {
  res.json(req.user.hotel || null);
});

export default router;