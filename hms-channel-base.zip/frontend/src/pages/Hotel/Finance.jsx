import React, { useEffect, useState } from 'react'
import api from '../../api/axios'
import Header from '../../components/Header'

export default function Finance(){
  const [items, setItems] = useState([])
  const [sum, setSum] = useState({income:0, expense:0, net:0})
  const [form, setForm] = useState({ type:'income', date:'', amount:'', category:'', description:'' })

  const load = async () => {
    const [a,b] = await Promise.all([api.get('/finance'), api.get('/finance/summary')])
    setItems(a.data); setSum(b.data)
  }
  useEffect(()=>{ load() },[])

  const create = async (e) => {
    e.preventDefault()
    await api.post('/finance', {...form, amount: Number(form.amount)})
    setForm({ type:'income', date:'', amount:'', category:'', description:'' })
    load()
  }

  return (
    <div>
      <Header title="Gelir - Gider" subtitle="Kayıtlar & Özet" />
      <div className="kpis">
        <div className="card"><div className="label">Gelir</div><div className="value">{sum.income.toLocaleString()} ₺</div></div>
        <div className="card"><div className="label">Gider</div><div className="value">{sum.expense.toLocaleString()} ₺</div></div>
        <div className="card"><div className="label">Net</div><div className="value">{sum.net.toLocaleString()} ₺</div></div>
      </div>
      <div className="card" style={{margin:'16px 0'}}>
        <form className="form-grid" onSubmit={create}>
          <select className="select" value={form.type} onChange={e=>setForm({...form, type:e.target.value})}>
            <option value="income">Gelir</option>
            <option value="expense">Gider</option>
          </select>
          <input className="input" type="date" value={form.date} onChange={e=>setForm({...form, date:e.target.value})} />
          <input className="input" type="number" placeholder="Tutar" value={form.amount} onChange={e=>setForm({...form, amount:e.target.value})} />
          <input className="input" placeholder="Kategori" value={form.category} onChange={e=>setForm({...form, category:e.target.value})} />
          <input className="input" placeholder="Açıklama" value={form.description} onChange={e=>setForm({...form, description:e.target.value})} />
          <button className="btn primary">Ekle</button>
        </form>
      </div>
      <div className="card">
        <table className="table">
          <thead><tr><th>Tarih</th><th>Tür</th><th>Kategori</th><th>Tutar</th><th>Açıklama</th></tr></thead>
          <tbody>
            {items.map(t => (
              <tr key={t._id}>
                <td>{new Date(t.date).toLocaleDateString()}</td>
                <td>{t.type}</td>
                <td>{t.category}</td>
                <td>{t.amount?.toLocaleString()} ₺</td>
                <td>{t.description}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}