import express from 'express';
import Transaction from '../models/Transaction.js';
import { auth, requireRole } from '../middleware/auth.js';

const router = express.Router();

router.get('/', auth, async (req, res) => {
  let filter = {};
  if (req.user.role !== 'MASTER_ADMIN') filter.hotel = req.user.hotel?._id;
  else if (req.query.hotelId) filter.hotel = req.query.hotelId;
  const items = await Transaction.find(filter).sort({ date: -1 });
  res.json(items);
});

router.post('/', auth, requireRole('HOTEL_ADMIN', 'HOTEL_STAFF'), async (req, res) => {
  const hotel = req.user.hotel?._id;
  const created = await Transaction.create({ ...req.body, hotel, createdBy: req.user._id });
  res.status(201).json(created);
});

router.get('/summary', auth, async (req, res) => {
  let match = {};
  if (req.user.role !== 'MASTER_ADMIN') match.hotel = req.user.hotel?._id;
  else if (req.query.hotelId) match.hotel = req.query.hotelId;

  if (req.query.start || req.query.end) {
    match.date = {};
    if (req.query.start) match.date.$gte = new Date(req.query.start);
    if (req.query.end) match.date.$lte = new Date(req.query.end);
  }

  const agg = await Transaction.aggregate([
    { $match: match },
    { $group: {
      _id: '$type',
      total: { $sum: '$amount' }
    }}
  ]);
  const income = agg.find(a => a._id === 'income')?.total || 0;
  const expense = agg.find(a => a._id === 'expense')?.total || 0;
  res.json({ income, expense, net: income - expense });
});

export default router;